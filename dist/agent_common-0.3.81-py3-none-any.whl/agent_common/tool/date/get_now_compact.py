# 작성일: 2026-08-21
# 설계자: 김유상 수석
# 설계자 소속: 경포씨엔씨
# 설계자 이메일: bakkus@kpcnc.co.kr, bakkus@daum.net

"""
현재 일시를 14자리 압축 포맷(YYYYMMDDHHMMSS)으로 반환하는 범용 Tool 함수입니다.
"""

from agent_common.utils import DateTimeUtils


def get_now_compact(*args: object, **kwargs: object) -> str:
    """
    현재 일시를 'YYYYMMDDHHMMSS' 형식의 14자리 문자열로 반환합니다.

    :return: 14자리 타임스탬프 문자열 (예: '20260821125000')
    """
    return DateTimeUtils.get_now_compact()
