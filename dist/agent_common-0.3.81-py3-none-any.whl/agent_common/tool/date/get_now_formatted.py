# 작성일: 2026-08-21
# 설계자: 김유상 수석
# 설계자 소속: 경포씨엔씨
# 설계자 이메일: bakkus@kpcnc.co.kr, bakkus@daum.net

"""
현재 일시를 지정한 포맷 문자열로 변환하여 반환하는 범용 Tool 함수입니다.
"""

from typing import Optional
from agent_common.utils import DateTimeUtils


def get_now_formatted(fmt_str: Optional[str] = None, *args: object, **kwargs: object) -> str:
    """
    현재 일시를 지정한 strftime 포맷(기본값: '%Y-%m-%d %H:%M:%S+09:00') 문자열로 반환합니다.

    :param fmt_str: strftime 포맷 문자열 (선택)
    :return: 포맷팅된 현재 일시 문자열
    """
    return DateTimeUtils.get_now_formatted(fmt_str=fmt_str)
