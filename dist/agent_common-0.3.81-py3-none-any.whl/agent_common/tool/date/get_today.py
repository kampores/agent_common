# 작성일: 2026-08-21
# 설계자: 김유상 수석
# 설계자 소속: 경포씨엔씨
# 설계자 이메일: bakkus@kpcnc.co.kr, bakkus@daum.net

"""
현재 일자를 8자리(YYYYMMDD) 형식으로 반환하는 범용 Tool 함수입니다.
"""

from agent_common.utils import DateTimeUtils


def get_today(*args: object, **kwargs: object) -> str:
    """
    현재 일자를 'YYYYMMDD' 형식의 8자리 문자열로 반환합니다.

    :return: 8자리 일자 문자열 (예: '20260821')
    """
    return DateTimeUtils.get_today_yyyymmdd()
